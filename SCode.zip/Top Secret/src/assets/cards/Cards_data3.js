import card_img26 from './card26.jpg';
import card_img27 from './card27.jpg';
import card_img28 from './card28.jpg';
import card_img29 from './card29.jpg';
import card_img30 from './card30.jpg';
import card_img31 from './card31.jpg';
import card_img32 from './card32.jpg';
import card_img33 from './card33.jpg';
import card_img34 from './card34.jpg';
import card_img35 from './card35.jpg';
import card_img36 from './card36.jpg';

const cards_data3 = [
    
    {
        image:card_img26,
        name:""
    },
    {
        image:card_img27,
        name:""
    },
    {
        image:card_img28,
        name:""
    },
    {
        image:card_img29,
        name:""
    },
    {
        image:card_img30,
        name:""
    },
    {
        image:card_img31,
        name:""
    },
    {
        image:card_img32,
        name:""
    },
    {
        image:card_img33,
        name:""
    },
    {
        image:card_img34,
        name:""
    },
    {
        image:card_img35,
        name:""
    },
    {
        image:card_img36,
        name:""
    },
]

export default cards_data3;