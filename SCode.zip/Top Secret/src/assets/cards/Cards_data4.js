import card_img37 from './card37.jpg';
import card_img38 from './card38.jpg';
import card_img39 from './card39.jpg';
import card_img40 from './card40.jpg';
import card_img41 from './card41.jpg';
import card_img42 from './card42.jpg';


const cards_data4 = [
    
    {
        image:card_img37,
        name:""
    },
    {
        image:card_img38,
        name:""
    },
    {
        image:card_img39,
        name:""
    },
    {
        image:card_img40,
        name:""
    },
    {
        image:card_img41,
        name:""
    },
    {
        image:card_img42,
        name:""
    },
    
]

export default cards_data4;