import card_img15 from './card15.jpg';
import card_img16 from './card16.jpg';
import card_img17 from './card17.jpg';
import card_img18 from './card18.jpg';
import card_img19 from './card19.jpg';
import card_img20 from './card20.jpg';
import card_img21 from './card21.jpg';
import card_img22 from './card22.jpg';
import card_img23 from './card23.jpg';
import card_img24 from './card24.jpg';
import card_img25 from './card25.jpg';

const cards_data2 = [
    {
        image:card_img15,
        name:""
    },
    {
        image:card_img16,
        name:""
    },
    {
        image:card_img17,
        name:""
    },
    {
        image:card_img18,
        name:""
    },
    {
        image:card_img19,
        name:""
    },
    {
        image:card_img20,
        name:""
    },
    {
        image:card_img21,
        name:""
    },
    {
        image:card_img22,
        name:""
    },
    {
        image:card_img23,
        name:""
    },
    {
        image:card_img24,
        name:""
    },
    {
        image:card_img25,
        name:""
    },
]

export default cards_data2;