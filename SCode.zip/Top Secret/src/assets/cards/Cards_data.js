import card_img1 from './card1.jpg';
import card_img2 from './card2.jpg';
import card_img3 from './card3.jpg';
import card_img4 from './card4.jpg';
import card_img5 from './card5.jpg';
import card_img6 from './card6.jpg';
import card_img7 from './card7.jpg';
import card_img8 from './card8.jpg';
import card_img9 from './card9.jpg';
import card_img10 from './card10.jpg';
import card_img11 from './card11.jpg';
import card_img12 from './card12.jpg';
import card_img13 from './card13.jpg';
import card_img14 from './card14.jpg';

const cards_data = [
    {
        image:card_img1,
        name:""
    },
    {
        image:card_img2,
        name:""
    },
    {
        image:card_img3,
        name:""
    },
    {
        image:card_img4,
        name:""
    },
    {
        image:card_img5,
        name:""
    },
    {
        image:card_img6,
        name:""
    },
    {
        image:card_img7,
        name:""
    },
    {
        image:card_img8,
        name:""
    },
    {
        image:card_img9,
        name:""
    },
    {
        image:card_img10,
        name:""
    },
    {
        image:card_img11,
        name:""
    },
    {
        image:card_img12,
        name:""
    },
    {
        image:card_img13,
        name:""
    },
    {
        image:card_img14,
        name:""
    },
]

export default cards_data;