import React, { useEffect, useRef } from 'react'
import './TitleCard3.css'
import cards_data3 from '../../assets/cards/Cards_data3'



const TitleCard3 = ({title, category}) => {

    const cardsRef = useRef();

    const handleWheel = (event)=>{
        event.preventDefault();
        cardsRef.current.scrollLeft += event.deltaY;
    }

    useEffect(()=>{
        cardsRef.current.addEventListener('wheel', handleWheel)
    },[])

    return (
        <div className='title-cards3'>
            <h2>{title?title:"Us"}</h2>
            <div className="card-list3" ref={cardsRef}>
                {cards_data3.map((card, index)=>{
                    return <div className="card" key={index}>
                        <img src={card.image} alt=''/>
                        <p>{card.name}</p>
                    </div>
                })}
            </div>
        </div>
    )
}

export default TitleCard3
