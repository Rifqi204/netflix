import React, { useEffect, useRef } from 'react'
import './TitleCard2.css'
import cards_data2 from '../../assets/cards/Cards_data2'



const TitleCard2 = ({title, category}) => {

    const cardsRef = useRef();

    const handleWheel = (event)=>{
        event.preventDefault();
        cardsRef.current.scrollLeft += event.deltaY;
    }

    useEffect(()=>{
        cardsRef.current.addEventListener('wheel', handleWheel)
    },[])

    return (
        <div className='title-cards2'>
            <h2>{title?title:"Sleepin'"}</h2>
            <div className="card-list2" ref={cardsRef}>
                {cards_data2.map((card, index)=>{
                    return <div className="card" key={index}>
                        <img src={card.image} alt=''/>
                        <p>{card.name}</p>
                    </div>
                })}
            </div>
        </div>
    )
}

export default TitleCard2
