import React, { useEffect, useRef } from 'react'
import './TitleCard4.css'
import cards_data4 from '../../assets/cards/Cards_data4'



const TitleCard4 = ({title, category}) => {

    const cardsRef = useRef();

    const handleWheel = (event)=>{
        event.preventDefault();
        cardsRef.current.scrollLeft += event.deltaY;
    }

    useEffect(()=>{
        cardsRef.current.addEventListener('wheel', handleWheel)
    },[])

    return (
        <div className='title-cards4'>
            <h2>{title?title:"Teu Ngenah Tapi Ludes"}</h2>
            <div className="card-list4" ref={cardsRef}>
                {cards_data4.map((card, index)=>{
                    return <div className="card" key={index}>
                        <img src={card.image} alt=''/>
                        <p>{card.name}</p>
                    </div>
                })}
            </div>
        </div>
    )
}

export default TitleCard4
