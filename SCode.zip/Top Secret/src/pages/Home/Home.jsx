import React, { useState } from 'react';
import "./Home.css";
import Navbar from '../../components/Navbar/Navbar';
import hero_banner from '../../assets/hero_banner.jpg';
import hero_title from '../../assets/hero_title.png';
import play_icons from '../../assets/play_icon.png';
import info_icons from '../../assets/info_icon.png';
import TitleCard from '../../components/TitleCard/TitleCard';
import Footer from '../../components/Footer/Footer';
import TitleCard2 from '../../components/TitleCard2/TitleCard2';
import TitleCard3 from '../../components/TitleCard3/TitleCard3';
import TitleCard4 from '../../components/TitleCard4/TitleCard4';
import popup_image from '../../assets/popup_image.jpg';
import more_info_image from '../../assets/more_info_image.jpg'

const Home = () => {
    const [showImage, setShowImage] = useState(false);
    const [showMoreInfoImage, setShowMoreInfoImage] = useState(false); 

    const handlePlayClick = () => {
        setShowImage(true);
    };

    const handleMoreInfoClick = () => {
        setShowMoreInfoImage(true);
    };

    const handleCloseClick = () => {
        setShowImage(false);
        setShowMoreInfoImage(false); 
    };

    return (
        <div className='home'>
            <Navbar />
            <div className="hero" id='awal' >
                <img src={hero_banner} alt="" className='banner-img' />
                <div className="hero-caption">
                    <img src={hero_title} alt='caption-img' className='caption-img' />
                    <p>This is .</p>
                    <p>Click 'Play' to see the details</p>
                    <div className="hero-btns">
                        <button className='btn' onClick={handlePlayClick}>
                            <img src={play_icons} alt='Play' />Play
                        </button>
                        <button className='btn dark-btn' onClick={handleMoreInfoClick}>
                            <img src={info_icons} alt='' />More Info
                        </button>
                    </div>
                    <section id='tv'><TitleCard /></section>
                </div>
            </div>
            <div className="more-cards">
                <section id='dreamin'><TitleCard2 /></section>
                <section id='abc'><TitleCard3 /></section>
                <section id='food'><TitleCard4 /></section>
            </div>
            <Footer />
            {showImage && (
                <>
                    <div 
                        style={{
                            position: 'fixed',
                            top: 0,
                            left: 0,
                            width: '100%',
                            height: '100%',
                            backgroundColor: 'rgba(0, 0, 0, 0.7)',
                            zIndex: 100
                        }}
                        onClick={handleCloseClick}
                    />
                    <div className="popup-image">
                        <img src={popup_image} alt="Popup" />
                        <h4 className=" popup-hlo">Haloo, </h4>
                        <div className='popup-text-wrapper'>
                            <p className="popup-text">A I want to say thank you, and once again sorry after all the things I've done. I know that my apologies won't be enough, for sure. I miss you here. May good things always accompany you. I hope we can be close again. If you want to talk to me, you can chat me in whatsapp or discord everytime you want. I'm sorry I lied, I didn't delete all these photos. I apologize if you're feeling weird, good luck for your 3rd semester.</p>
                        </div>
                        {/* <button className="close-btn" onClick={handleCloseClick}>Close</button> */}
                    </div>
                </>
                
            )}
            
            {showMoreInfoImage && (
                <>
                <div 
                        style={{
                            position: 'fixed',
                            top: 0,
                            left: 0,
                            width: '100%',
                            height: '100%',
                            backgroundColor: 'rgba(0, 0, 0, 0.7)',
                            zIndex: 100
                        }}
                        onClick={handleCloseClick}
                    />
                    <div className="overlay" onClick={handleCloseClick} />
                    <div className="popup-image" onClick={(e) => e.stopPropagation()}>
                        <img src={more_info_image} alt="More Info Popup" />
                        <p className="popup-text">No ingfo bang, kalau ada ingfo langsung gaskan.</p>
                        {/* <button className="close-btn" onClick={handleCloseClick}>Close</button> */}
                    </div>
                </>
            )}
        </div>
    );
}

export default Home;
