import React from 'react'
import './Player.css'

const Player = () => {
    return (
        <div className='player'>
            
        </div>
    )
}

export default Player
